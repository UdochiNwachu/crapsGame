package com.example.crapsgamemodified

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button = findViewById<View>(R.id.button) as Button
        button.setOnClickListener { openActivity2() }
    }

    fun openActivity2() {
        val editText1 = findViewById<View>(R.id.edittext1) as EditText
        val text = editText1.text.toString()
        val editText2 = findViewById<View>(R.id.edittext2) as EditText
        val number = editText2.text.toString().toInt()
        val intent = Intent(this, Activity2::class.java)
        intent.putExtra(EXTRA_TEXT, text)
        intent.putExtra(EXTRA_NUMBER, number)
        startActivity(intent)
    }

    companion object {
        const val EXTRA_TEXT = "com.example.application.example.EXTRA_TEXT"
        const val EXTRA_NUMBER = "com.example.application.example.EXTRA_NUMBER"
    }
}