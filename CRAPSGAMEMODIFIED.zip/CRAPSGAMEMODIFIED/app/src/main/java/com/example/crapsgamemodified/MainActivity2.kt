package com.example.crapsgamemodified

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class Activity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val intent = intent
        val text = intent.getStringExtra(MainActivity.EXTRA_TEXT)
        val number = intent.getIntExtra(MainActivity.EXTRA_NUMBER, 0)
        val textView1 = findViewById<View>(R.id.textview1) as TextView
        val textView2 = findViewById<View>(R.id.textview2) as TextView
        textView1.text = text
        textView2.text = "" + number
    }
}